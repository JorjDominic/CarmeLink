import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  group('UI P2B discoverability contract', () {
    test('tenant dashboard exposes Phase 3 to 4 resident tools', () {
      final source =
          File('lib/views/tenant/tenant_pages.dart').readAsStringSync();

      expect(source.contains("'Resident tools'"), isTrue);
      expect(source.contains("label: 'Cleaning'"), isTrue);
      expect(source.contains('TenantCleaningSchedulePage()'), isTrue);
      expect(source.contains("label: 'Inspections'"), isTrue);
      expect(source.contains('TenantRoomInspectionsPage()'), isTrue);
      expect(source.contains("label: 'Conduct & appeals'"), isTrue);
      expect(source.contains('TenantConductCasesPage()'), isTrue);
      expect(source.contains("label: 'Work curfew'"), isTrue);
    });

    test('guardian quick access prioritizes core linked-tenant tasks', () {
      final source =
          File('lib/views/guardian/guardian_pages.dart').readAsStringSync();

      expect(source.contains("label: 'Tenant info'"), isTrue);
      expect(source.contains("label: 'Payments'"), isTrue);
      expect(source.contains("label: 'Curfew'"), isTrue);
      expect(source.contains("label: 'Messages'"), isTrue);
    });

    test('staff operations surfaces expose current Phase 3 to 5 modules', () {
      final source =
          File('lib/views/owner/owner_pages.dart').readAsStringSync();

      expect(source.contains("'Cleaning schedules'"), isTrue);
      expect(source.contains("'Room inspections'"), isTrue);
      expect(source.contains("'Conduct & cases'"), isTrue);
      expect(source.contains("'Security & retention'"), isTrue);
      expect(source.contains('EmployeeCurfewProfilesPage()'), isTrue);
      expect(source.contains('VisitorManagementPage()'), isTrue);
    });

    test(
        'web staff sidebar exposes grouped desktop tools while Operations remains available',
        () {
      final shell = File(
        'lib/web/dashboard/staff_web_portal_shell.dart',
      ).readAsStringSync();
      final owner = File('lib/views/owner/owner_pages.dart').readAsStringSync();

      expect(shell.contains("label: 'Residents'"), isTrue);
      expect(shell.contains("label: 'Operations'"), isTrue);
      expect(
        shell.contains('static List<AppDestination> desktopTools(UserRole role)'),
        isTrue,
      );
      // Original (main): shell.contains('static List<AppDestination> desktopTools')
      expect(shell.contains("webGroup: 'Facilities'"), isTrue);
      expect(shell.contains("webGroup: 'Access & Safety'"), isTrue);
      expect(shell.contains("webGroup: 'Billing & Records'"), isTrue);
      expect(shell.contains("webGroup: 'Communication'"), isTrue);
      expect(shell.contains("webGroup: 'Administration'"), isTrue);

      for (final label in [
        'Cleaning schedules',
        'Room inspections',
        'Visitors',
        'Conduct & cases',
        'Employee curfew profiles',
        'Security & retention',
      ]) {
        expect(
          owner.contains(label),
          isTrue,
          reason: 'Operations hub is missing $label',
        );
      }
    });
  });
}

import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/config/supabase_config.dart';
import '../core/constants/official_lease_content.dart';
import '../models/models.dart';

class GeneratedContractFile {
  const GeneratedContractFile({required this.document, required this.bytes});
  final ContractDocument document;
  final Uint8List bytes;
}

class ContractDocumentService {
  const ContractDocumentService();

  static const _bucket = 'contract-documents';
  static const _selection =
      'id, contract_id, version, document_type, storage_path, '
      'original_filename, mime_type, size_bytes, sha256, review_status, '
      'uploaded_at, reviewed_at, review_notes';

  SupabaseClient get _client => SupabaseConfig.client;

  Future<List<ContractDocument>> listDocuments(String contractId) async {
    final rows = await _client
        .from('contract_documents')
        .select(_selection)
        .eq('contract_id', contractId)
        .order('version', ascending: false)
        .order('document_type');
    return rows.map(ContractDocument.fromRow).toList();
  }

  Future<GeneratedContractFile> generateContract(
      TenantContract contract) async {
    final existing = await listDocuments(contract.id);
    if (existing.any((item) => item.isGenerated)) {
      throw Exception(
          'A printable contract already exists. Delete it before generating another.');
    }
    final version = await _nextVersion(contract.id);
    final roomNumber = await _assignedRoomNumber(contract.tenantId);
    if (roomNumber == null) {
      throw Exception(
        'Assign the tenant to a room before generating the official lease.',
      );
    }
    final bytes = await buildPdfBytes(
      contract,
      version,
      roomNumber: roomNumber,
    );
    final filename = '${contract.contractNumber}-v$version.pdf';
    final path = '${contract.id}/v$version/generated-'
        '${DateTime.now().toUtc().microsecondsSinceEpoch}.pdf';
    await _upload(path, bytes, 'application/pdf');
    late final ContractDocument document;
    try {
      document = await _register(
        contractId: contract.id,
        version: version,
        documentType: 'generated',
        path: path,
        filename: filename,
        mimeType: 'application/pdf',
        bytes: bytes,
      );
    } catch (_) {
      await _client.storage.from(_bucket).remove([path]);
      rethrow;
    }
    return GeneratedContractFile(document: document, bytes: bytes);
  }

  Future<ContractDocument> uploadSigned({
    required TenantContract contract,
    required int version,
    required String filename,
    required String mimeType,
    required Uint8List bytes,
  }) async {
    final existing = await listDocuments(contract.id);
    if (existing.any((item) => item.isSigned)) {
      throw Exception(
          'A signed copy already exists. Delete it before uploading another.');
    }
    if (bytes.isEmpty || bytes.length > 10 * 1024 * 1024) {
      throw Exception('Signed document must be 10 MB or smaller.');
    }
    const allowed = {'application/pdf', 'image/jpeg', 'image/png'};
    if (!allowed.contains(mimeType)) {
      throw Exception('Upload a PDF, JPG, or PNG document.');
    }
    final extension = switch (mimeType) {
      'application/pdf' => 'pdf',
      'image/png' => 'png',
      _ => 'jpg',
    };
    final path = '${contract.id}/v$version/signed-'
        '${DateTime.now().toUtc().microsecondsSinceEpoch}.$extension';
    await _upload(path, bytes, mimeType);
    try {
      return await _register(
        contractId: contract.id,
        version: version,
        documentType: 'signed',
        path: path,
        filename: filename,
        mimeType: mimeType,
        bytes: bytes,
      );
    } catch (_) {
      await _client.storage.from(_bucket).remove([path]);
      rethrow;
    }
  }

  /// Builds and registers the immutable execution copy after every required
  /// signer has been independently verified. No manual signed-file upload is
  /// involved in the digital workflow.
  Future<ContractDocument?> finalizeDigitalExecution(
      TenantContract contract) async {
    final signerRows = await _client
        .from('contract_signers')
        .select()
        .eq('contract_id', contract.id);
    final signers = signerRows.map(ContractSigner.fromRow).toList();
    final required = signers
        .where((item) =>
            item.isRequired && (item.role == 'tenant' || item.role == 'lessor'))
        .toList();
    if (required.isEmpty || required.any((item) => !item.isVerified)) {
      return null;
    }
    final documents = await listDocuments(contract.id);
    final existing = documents.where((item) => item.isSigned).firstOrNull;
    if (existing != null) return existing;
    final generated = documents.where((item) => item.isGenerated).firstOrNull;
    if (generated == null) return null;

    final signatureImages = <String, Uint8List>{};
    final signerNames = <String, String>{};
    final signedDates = <String, DateTime>{};
    for (final signer in signers) {
      if (signer.signerName?.isNotEmpty == true) {
        signerNames[signer.role] = signer.signerName!;
      }
      if (signer.signedAt != null) signedDates[signer.role] = signer.signedAt!;
      final path = signer.signatureStoragePath;
      if (path != null) {
        signatureImages[signer.role] =
            await _client.storage.from(_bucket).download(path);
      }
    }
    final roomNumber = await _assignedRoomNumber(contract.tenantId);
    final bytes = await buildPdfBytes(
      contract,
      generated.version,
      roomNumber: roomNumber,
      signatureImages: signatureImages,
      signerNames: signerNames,
      signedDates: signedDates,
      digitallyExecuted: true,
    );
    final signed = await uploadSigned(
      contract: contract,
      version: generated.version,
      filename: '${contract.contractNumber}-executed-v${generated.version}.pdf',
      mimeType: 'application/pdf',
      bytes: bytes,
    );
    return reviewSignedDocument(
      documentId: signed.id,
      approve: true,
      notes:
          'Automatically assembled from independently verified digital signatures.',
    );
  }

  Future<ContractDocument> reviewSignedDocument({
    required String documentId,
    required bool approve,
    required String notes,
  }) async {
    final row = await _client.rpc('review_signed_contract_document', params: {
      'p_document_id': documentId,
      'p_approve': approve,
      'p_notes': notes.trim(),
    });
    return ContractDocument.fromRow(Map<String, dynamic>.from(row as Map));
  }

  Future<Uint8List> downloadDocument(String storagePath) async =>
      _client.storage.from(_bucket).download(storagePath);

  Future<void> deleteVersion({
    required String contractId,
    required int version,
    required List<String> storagePaths,
  }) async {
    final deleted = await _client
        .from('contract_documents')
        .delete()
        .eq('contract_id', contractId)
        .eq('version', version)
        .select('id');
    if (deleted.isEmpty) {
      throw Exception('Document version could not be deleted.');
    }
    if (storagePaths.isNotEmpty) {
      await _client.storage.from(_bucket).remove(storagePaths);
    }
  }

  Future<int> _nextVersion(String contractId) async {
    final rows = await _client
        .from('contract_documents')
        .select('version')
        .eq('contract_id', contractId)
        .eq('document_type', 'generated')
        .order('version', ascending: false)
        .limit(1);
    return rows.isEmpty ? 1 : (rows.first['version'] as int) + 1;
  }

  Future<String?> _assignedRoomNumber(String tenantId) async {
    final row = await _client
        .from('tenant_assignments')
        .select('bed_spaces!inner(rooms!inner(room_number))')
        .eq('tenant_id', tenantId)
        .eq('status', 'active')
        .maybeSingle();
    final bed = row?['bed_spaces'] as Map<String, dynamic>?;
    final room = bed?['rooms'] as Map<String, dynamic>?;
    final number = room?['room_number']?.toString().trim();
    return number == null || number.isEmpty ? null : number;
  }

  Future<void> _upload(String path, Uint8List bytes, String mimeType) async {
    await _client.storage.from(_bucket).uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: mimeType, upsert: false),
        );
  }

  Future<ContractDocument> _register({
    required String contractId,
    required int version,
    required String documentType,
    required String path,
    required String filename,
    required String mimeType,
    required Uint8List bytes,
  }) async {
    final row = await _client
        .from('contract_documents')
        .insert({
          'contract_id': contractId,
          'version': version,
          'document_type': documentType,
          'storage_path': path,
          'original_filename': filename,
          'mime_type': mimeType,
          'size_bytes': bytes.length,
          'sha256': sha256.convert(bytes).toString(),
          'review_status':
              documentType == 'generated' ? 'not_required' : 'pending',
        })
        .select(_selection)
        .single();
    return ContractDocument.fromRow(row);
  }

  /// Builds the printable document independently from storage registration.
  /// Public so PDF pagination can be regression-tested without Supabase.
  Future<Uint8List> buildPdfBytes(
    TenantContract contract,
    int version, {
    String? roomNumber,
    Map<String, Uint8List> signatureImages = const {},
    Map<String, String> signerNames = const {},
    Map<String, DateTime> signedDates = const {},
    bool digitallyExecuted = false,
  }) async {
    final document = pw.Document(
      version: PdfVersion.pdf_1_5,
      title: '${contract.contractNumber} version $version',
      author: 'CarmeLink',
      creator: 'CarmeLink Contract Register',
    );
    final generatedAt = DateTime.now().toUtc();
    String date(DateTime value) =>
        '${value.year}-${value.month.toString().padLeft(2, '0')}-'
        '${value.day.toString().padLeft(2, '0')}';
    String amount(double value) => 'PHP ${value.toStringAsFixed(2)}';

    document.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(48),
      header: (_) => pw.Container(
        padding: const pw.EdgeInsets.only(bottom: 12),
        decoration: const pw.BoxDecoration(
          border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey400)),
        ),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text("CARMELITA'S GIRLS-ONLY DORMITORY",
                style:
                    pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
            pw.Text('Contract v$version',
                style: const pw.TextStyle(color: PdfColors.grey700)),
          ],
        ),
      ),
      footer: (context) => pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text('Generated by CarmeLink - ${generatedAt.toIso8601String()}',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
          pw.Text('Page ${context.pageNumber} of ${context.pagesCount}',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
        ],
      ),
      build: (_) => [
        pw.SizedBox(height: 24),
        pw.Text(OfficialLeaseContent.title.toUpperCase(),
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 8),
        pw.Text('Contract No. ${contract.contractNumber}',
            textAlign: pw.TextAlign.center,
            style: const pw.TextStyle(color: PdfColors.grey700)),
        pw.SizedBox(height: 30),
        _pdfSection('Parties and resident', [
          _pdfRow('Lessor', OfficialLeaseContent.lessorName),
          _pdfRow('Dormitory address', OfficialLeaseContent.address),
          _pdfRow('Tenant name', contract.tenantName),
          _pdfRow('Assigned room', roomNumber ?? 'Not assigned'),
          _pdfRow('Tenant profile ID', contract.tenantId),
        ]),
        _pdfSection('Agreement term', [
          _pdfRow('Start date', date(contract.startsOn)),
          _pdfRow('End date', date(contract.endsOn)),
        ]),
        _pdfSection('Financial terms', [
          _pdfRow('Monthly rent', amount(contract.monthlyRent)),
          _pdfRow(
              'Rent due every', 'Day ${contract.billingDueDay} of the month'),
          _pdfRow('Security deposit', amount(contract.securityDeposit)),
        ]),
        _pdfBulletSection(
          'Required documents before move-in',
          OfficialLeaseContent.requiredDocuments,
        ),
        _pdfSection(
          'Rules, regulations, and stated consequences',
          OfficialLeaseContent.rules
              .map((rule) => pw.Padding(
                    padding: const pw.EdgeInsets.only(bottom: 8),
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(rule.title,
                            style:
                                pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                        pw.Text(rule.details),
                        if (rule.consequence != null)
                          pw.Text('Penalty/consequence: ${rule.consequence}',
                              style:
                                  const pw.TextStyle(color: PdfColors.grey700)),
                      ],
                    ),
                  ))
              .toList(),
        ),
        _pdfBulletSection(
          'Security deposit conditions',
          <String>[
            'Refundable within 30 days after the lease ends, subject to:',
            ...OfficialLeaseContent.depositConditions,
          ],
        ),
        _pdfBulletSection(
          'Dormitory rights and inspections',
          const <String>[
            'The lessor may inspect rooms monthly to ensure safety and cleanliness.',
            'Written notice will be given at least three days in advance.',
            'Tenants must allow access during the scheduled inspection.',
          ],
        ),
        _pdfBulletSection(
          'Termination and eviction',
          OfficialLeaseContent.terminationReasons,
        ),
        _pdfBulletSection(
          'Miscellaneous',
          OfficialLeaseContent.miscellaneous,
        ),
        _pdfSection('Contacting the owner', [
          pw.Text(OfficialLeaseContent.ownerContact),
        ]),
        if (contract.notes?.trim().isNotEmpty == true)
          _pdfSection('Additional notes', [pw.Text(contract.notes!.trim())]),
        pw.SizedBox(height: 22),
        pw.Text(
          'By signing, both parties agree to all terms and understand the '
          'consequences of violating this agreement.',
          style: const pw.TextStyle(height: 1.5),
        ),
        pw.SizedBox(height: 56),
        pw.Row(children: [
          pw.Expanded(
              child: _signatureBlock('tenant', 'Tenant', signatureImages,
                  signerNames, signedDates)),
          pw.SizedBox(width: 36),
          pw.Expanded(
              child: _signatureBlock('lessor', 'Owner', signatureImages,
                  signerNames, signedDates)),
        ]),
        pw.SizedBox(height: 44),
        pw.Row(children: [
          pw.Expanded(
              child: _signatureBlock('guardian', 'Parent / guardian',
                  signatureImages, signerNames, signedDates)),
          pw.SizedBox(width: 36),
          pw.Expanded(
              child: _signatureBlock('witness', 'Witness (optional)',
                  signatureImages, signerNames, signedDates)),
        ]),
        pw.SizedBox(height: 44),
        pw.Container(
          width: double.infinity,
          padding: const pw.EdgeInsets.all(12),
          color: PdfColors.grey200,
          child: pw.Text(
            digitallyExecuted
                ? 'Digitally executed version $version. Signature images, signer identities, timestamps, and hashes are retained as immutable CarmeLink evidence.'
                : 'Document version $version is immutable in CarmeLink. Required parties sign on-screen; verified signatures are assembled into a final digital execution copy.',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
        ),
      ],
    ));
    return document.save();
  }

  pw.Widget _pdfSection(String title, List<pw.Widget> children) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(title,
              style:
                  pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          ...children.map(
            (child) => pw.Container(
              width: double.infinity,
              margin: const pw.EdgeInsets.only(bottom: 5),
              padding: const pw.EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 8,
              ),
              decoration: pw.BoxDecoration(
                color: PdfColors.grey100,
                border: pw.Border.all(color: PdfColors.grey400),
                borderRadius: pw.BorderRadius.circular(4),
              ),
              child: child,
            ),
          ),
          pw.SizedBox(height: 13),
        ],
      );

  pw.Widget _pdfRow(String label, String value) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 4),
        child: pw.Row(children: [
          pw.SizedBox(
              width: 130,
              child: pw.Text(label,
                  style: const pw.TextStyle(color: PdfColors.grey700))),
          pw.Expanded(child: pw.Text(value)),
        ]),
      );

  pw.Widget _pdfBulletSection(String title, List<String> items) => _pdfSection(
        title,
        items
            .map((item) => pw.Padding(
                  padding: const pw.EdgeInsets.only(bottom: 5),
                  child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text('-  '),
                      pw.Expanded(child: pw.Text(item)),
                    ],
                  ),
                ))
            .toList(),
      );

  pw.Widget _signatureLine(String label) => pw.Column(children: [
        pw.Container(
          height: 1,
          margin: const pw.EdgeInsets.only(bottom: 8),
          color: PdfColors.black,
        ),
        pw.Text(label, style: const pw.TextStyle(fontSize: 9)),
      ]);

  pw.Widget _signatureBlock(
    String role,
    String label,
    Map<String, Uint8List> images,
    Map<String, String> names,
    Map<String, DateTime> dates,
  ) {
    final image = images[role];
    final name = names[role];
    final date = dates[role];
    if (image == null && name == null)
      return _signatureLine('$label signature and date');
    final dateText = date == null
        ? ''
        : '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
    return pw.Column(children: [
      pw.SizedBox(
        height: 42,
        child: image == null
            ? pw.SizedBox()
            : pw.Image(pw.MemoryImage(image), fit: pw.BoxFit.contain),
      ),
      pw.Divider(),
      pw.Text(name ?? label,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
      pw.Text('$label · $dateText', style: const pw.TextStyle(fontSize: 8)),
    ]);
  }
}
